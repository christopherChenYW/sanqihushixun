package com.example.myapplication.pojo;

public class Music {
    long id;
    String title;
    String artist;
    String url;

    public Music(long id, String title, String artist, long duration, long size, String url){
        this.id=id;
        this.title=title;
        this.artist=artist;
        this.url=url;
    };
    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getArtist() {
        return artist;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}
