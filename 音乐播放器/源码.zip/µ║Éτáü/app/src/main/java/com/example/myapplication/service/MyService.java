package com.example.myapplication.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.MediaActivity;
import com.example.myapplication.R;
import com.example.myapplication.pojo.Fruit;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service {

    private MediaPlayer mediaPlayer;//媒体播放器
    private Fruit fruit;
    private Button playButton;
    private Button replayButton;
    private boolean isCellPlay;/*在挂断电话的时候，用于判断是否为是来电时中断*/
    private boolean isSeekBarChanging;//互斥变量，防止进度条与定时器冲突。
    private int currentPosition;//当前音乐播放的进度
    private SeekBar seekBar;
    private Timer timer;
    private static final String TAG = "MediaActivity";

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        fruit = (Fruit) intent.getSerializableExtra("song");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        //实例化媒体播放器
        mediaPlayer = new MediaPlayer();
        play();
    }

    /*播放处理*/
    private void play() {

        File media = new File(fruit.getUrl());//由于是练习，就把mp3名称固定了
        Log.i(TAG, media.getAbsolutePath());
        if (media.exists()) {
            try {
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);//设置音频类型
                mediaPlayer.setDataSource(media.getAbsolutePath());//设置mp3数据源
                mediaPlayer.prepareAsync();//数据缓冲
                /*监听缓存 事件，在缓冲完毕后，开始播放*/
                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    public void onPrepared(MediaPlayer mp) {
                        mp.start();
                        mp.seekTo(currentPosition);
                        seekBar.setMax(mediaPlayer.getDuration());
                    }
                });
                //监听播放时回调函数
                timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if (!isSeekBarChanging) {
                            seekBar.setProgress(mediaPlayer.getCurrentPosition());
                        }
                    }
                }, 0, 50);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "播放错误", Toast.LENGTH_LONG).show();
                e.printStackTrace();
                System.out.println(e);
            }
        } else {
            Toast.makeText(getApplicationContext(), "文件加载错误", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}