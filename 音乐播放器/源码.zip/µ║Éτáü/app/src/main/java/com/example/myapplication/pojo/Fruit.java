package com.example.myapplication.pojo;

import java.io.Serializable;

public class Fruit implements Serializable {

    private String name;
    private int imageId;
    private String url;
    private String author;

    public Fruit(String name, int imageId, String url, String author) {
        this.name = name;
        this.imageId = imageId;
        this.author = author;
        this.url = url;

    }
    public String getAuthor(){
        return this.author;
    }
    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public int getImageId() {
        return imageId;
    }
}