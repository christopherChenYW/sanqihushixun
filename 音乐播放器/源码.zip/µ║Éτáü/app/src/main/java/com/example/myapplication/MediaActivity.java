package com.example.myapplication;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.myapplication.pojo.Fruit;

import java.io.File;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @CreateDate 2015-2-3
 * @Author hubiao
 * @Title 音乐播放器
 */
public class MediaActivity extends Activity {
    private MediaPlayer mediaPlayer;//媒体播放器
    private int position;
    private Fruit fruit;
    private List<Fruit> mFruitList;
    private Button playButton;
    private Button replayButton;
    private boolean isCellPlay;/*在挂断电话的时候，用于判断是否为是来电时中断*/
    private boolean isSeekBarChanging;//互斥变量，防止进度条与定时器冲突。
    private int currentPosition;//当前音乐播放的进度
    private SeekBar seekBar;
    private Timer timer;
    private Animation mLoadingAnim;
    private static final String TAG = "MediaActivity";
    private ImageView mLoadingImageView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play);
        //获取歌曲数据
        Intent intent = getIntent();
        mFruitList = (List<Fruit>) intent.getSerializableExtra("songList");
        position=intent.getIntExtra("position",0);
        fruit=mFruitList.get(position);

        TextView textView = findViewById(R.id.mediaFileName);
        textView.setText(fruit.getName() + ".mp3");

        mLoadingImageView=findViewById(R.id.image1);
        mLoadingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate_anim);
        //实例化媒体播放器
        mediaPlayer = new MediaPlayer();

        //监听滚动条事件
        seekBar = (SeekBar) findViewById(R.id.playSeekBar);
        seekBar.setOnSeekBarChangeListener(new MySeekBar());

        // 监听[播放或暂停]事件
        playButton = (Button) findViewById(R.id.playButton);
        playButton.setOnClickListener(new PlayListener());

        //监听[重播]事件
        replayButton = (Button) findViewById(R.id.replayButton);
        replayButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mediaPlayer.reset();
                currentPosition = 0;
                playButton.setText("停止");
                mLoadingImageView.startAnimation(mLoadingAnim);
                play();
            }
        });


        //监听[重播]事件
        Button nextButton = (Button) findViewById(R.id.nextSong);
        nextButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                position=(position+1)%mFruitList.size();
                fruit=mFruitList.get(position);
                TextView textView = findViewById(R.id.mediaFileName);
                textView.setText(fruit.getName() + ".mp3");
                mediaPlayer.reset();
                currentPosition = 0;
                playButton.setText("停止");
                mLoadingImageView.startAnimation(mLoadingAnim);
                play();
            }
        });
        //监听来电事件
        TelephonyManager phoneyMana = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        phoneyMana.listen(new myPhoneStateListener(), PhoneStateListener.LISTEN_CALL_STATE);
    }

    /*销毁时释资源*/
    @Override
    protected void onDestroy() {
        if(mediaPlayer!=null){
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if(timer!=null){
            timer.cancel();
            timer = null;
        }
        super.onDestroy();
    }

    /*播放或暂停事件处理*/
    private class PlayListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.reset();
                play();
                playButton.setText("停止");

                mLoadingImageView.startAnimation(mLoadingAnim);

            } else {
                playButton.setText("播放");
                currentPosition = mediaPlayer.getCurrentPosition();//记录播放的位置
                mediaPlayer.stop();//暂停状态
                timer.purge();//移除所有任务;
                mLoadingImageView.clearAnimation();
            }
        }
    }

    /*播放处理*/
    private void play() {

        File media = new File(fruit.getUrl());//由于是练习，就把mp3名称固定了
        Log.i(TAG, media.getAbsolutePath());
        if (media.exists()) {
            try {
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);//设置音频类型
                mediaPlayer.setDataSource(media.getAbsolutePath());//设置mp3数据源
                mediaPlayer.prepareAsync();//数据缓冲
                /*监听缓存 事件，在缓冲完毕后，开始播放*/
                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    public void onPrepared(MediaPlayer mp) {
                        mp.start();
                        mp.seekTo(currentPosition);
                        seekBar.setMax(mediaPlayer.getDuration());
                    }
                });
                //监听播放时回调函数
                timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if (!isSeekBarChanging) {
                            seekBar.setProgress(mediaPlayer.getCurrentPosition());
                        }
                    }
                }, 0, 50);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "播放错误", Toast.LENGTH_LONG).show();
                e.printStackTrace();
                System.out.println(e);
            }
        } else {
            Toast.makeText(getApplicationContext(), "文件加载错误", Toast.LENGTH_LONG).show();
        }
    }

    /*来电事件处理*/
    private class myPhoneStateListener extends PhoneStateListener {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING://来电，应当停止音乐
                    if (mediaPlayer.isPlaying() && playButton.getText().toString().equals("播放")) {
                        currentPosition = mediaPlayer.getCurrentPosition();//记录播放的位置
                        mediaPlayer.stop();
                        isCellPlay = true;//标记这是属于来电时暂停的标记
                        playButton.setText("暂停播放");
                        timer.purge();//移除定时器任务;
                    }
                    break;
                case TelephonyManager.CALL_STATE_IDLE://无电话状态
                    if (isCellPlay) {
                        isCellPlay = false;
                        mediaPlayer.reset();
                        play();
                    }
                    break;
            }
        }
    }

    /*进度条处理*/
    public class MySeekBar implements SeekBar.OnSeekBarChangeListener {

        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
        }

        /*滚动时,应当暂停后台定时器*/
        public void onStartTrackingTouch(SeekBar seekBar) {
            isSeekBarChanging = true;
        }

        /*滑动结束后，重新设置值*/
        public void onStopTrackingTouch(SeekBar seekBar) {
            isSeekBarChanging = false;
            mediaPlayer.seekTo(seekBar.getProgress());
        }
    }
}