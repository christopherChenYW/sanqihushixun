package org.cyw.httpclientandstroage.util;


import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileUtils {
    public final static String TAG = "FileUtils";


    /**
     * 保存内容到文件
     *
     * @param filePath 文件路径
     * @param content  文件内容
     */
    public static void save2File(String filePath, String content) {
        Log.i(TAG, "---save2File---:" + content);
        try {
            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            FileOutputStream fos = new FileOutputStream(filePath, true);
            byte[] buffer = content.getBytes();
            fos.write(buffer);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 读取文件内容
     *
     * @param filePath 文件路径
     * @return 文件内容
     */
    public static String readFile(String filePath) {
        String content = null;
        try {
            StringBuffer sb = new StringBuffer();
            FileInputStream fis = new FileInputStream(filePath);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(fis, "UTF-8"));
            String data = "";
            while ((data = br.readLine()) != null) {
                sb.append(data);
            }
            content = sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
            content = "";
        }
        return content;
    }

}

