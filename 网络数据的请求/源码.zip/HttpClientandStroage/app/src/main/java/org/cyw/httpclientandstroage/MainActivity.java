package org.cyw.httpclientandstroage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.cyw.httpclientandstroage.adapter.ArticleAdapter;
import org.cyw.httpclientandstroage.pojo.Article;
import org.cyw.httpclientandstroage.service.HttpService;
import org.cyw.httpclientandstroage.util.FileUtils;
import org.cyw.httpclientandstroage.util.RetrofitFactory;
import org.cyw.httpclientandstroage.view.SpaceItemDecoration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import okhttp3.internal.Internal;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<Article> articles=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestStoragePermission();
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showList(408,1);
            }
        });
        findViewById(R.id.save_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Gson gson=new Gson();
                gson.toJson(articles);
                FileUtils.save2File("/data/data/org.cyw.httpclientandstroage/myfile.txt",gson.toJson(articles));
            }
        });
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


    }
    public void showList(Integer authorId,Integer curPage){
        Runnable runnable=()->{
            HttpService httpService = RetrofitFactory.getInstance().bindService(HttpService.class);
            Call<ResponseBody> call = httpService.getArticles(authorId, curPage);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        String result = response.body().string();
                        JsonParser parser = new JsonParser();
                        JsonObject obj = parser.parse(result).getAsJsonObject();
                        JsonArray subArgs = obj.get("data").getAsJsonObject()
                                .get("datas").getAsJsonArray();
                        Gson gson=new Gson();
                        for(int i=0;i<subArgs.size();i++){
                            Article article=gson.fromJson(subArgs.get(i).toString(),Article.class);
                            articles.add(article);
                        }
                        ArticleAdapter adapter = new ArticleAdapter(articles);
                        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(getBaseContext(), DividerItemDecoration.VERTICAL);
                        recyclerView.addItemDecoration(dividerItemDecoration);
                        recyclerView.addItemDecoration(new SpaceItemDecoration(0, 30));
                        recyclerView.setAdapter(adapter);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {

                }
            });
        };
        runnable.run();
    }
    //检查权限，并返回需要申请的权限列表
    private List<String> checkPermission(Context context, String[] checkList) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < checkList.length; i++) {
            if (PackageManager.PERMISSION_GRANTED != ActivityCompat.checkSelfPermission(context, checkList[i])) {
                list.add(checkList[i]);
            }
        }
        return list;
    }

    //申请权限
    private void requestStoragePermission() {
        String[] checkList = new String[]{Manifest.permission.INTERNET,Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
        List<String> needRequestList = checkPermission(this, checkList);
        if (needRequestList.isEmpty()) {
            Toast.makeText(MainActivity.this, "无需申请权限", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(this, checkList, 100);
        }

    }
}