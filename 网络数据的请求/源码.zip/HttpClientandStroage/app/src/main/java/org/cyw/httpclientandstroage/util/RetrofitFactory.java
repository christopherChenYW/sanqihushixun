package org.cyw.httpclientandstroage.util;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitFactory {
    private static final int DEFAULT_CONNECT_TIME = 10;
    private static final int DEFAULT_WRITE_TIME = 30;
    private static final int DEFAULT_READ_TIME = 30;
    private static String REQUEST_BASE_URL = "https://www.wanandroid.com/";

    private final Retrofit retrofit;

    /**
     * 禁止外部创建实例
     */
    private RetrofitFactory() {

        OkHttpClient  okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(DEFAULT_CONNECT_TIME, TimeUnit.SECONDS)//连接超时时间
                .writeTimeout(DEFAULT_WRITE_TIME, TimeUnit.SECONDS)//设置写操作超时时间
                .readTimeout(DEFAULT_READ_TIME, TimeUnit.SECONDS)//设置读操作超时时间
                .build();

        retrofit = new Retrofit.Builder()
                .client(okHttpClient)//设置使用okhttp网络请求
                .baseUrl(REQUEST_BASE_URL)//设置服务器路径
                .addConverterFactory(GsonConverterFactory.create())//添加转化库，默认是Gson
                //.addCallAdapterFactory(RxJavaCallAdapterFactory.create())//添加回调库，采用RxJava
                .build();
    }

    public static void setREQUEST_BASE_URL(String url){
        REQUEST_BASE_URL=url;
    }

    private static class SingletonHolder{
        public static RetrofitFactory retrofitFactory=new RetrofitFactory();
    }

    /*
     * 获取RetrofitServiceManager
     **/
    public static RetrofitFactory getInstance() {
        return SingletonHolder.retrofitFactory;
    }

    public <T> T bindService(Class<T> service) {
        return retrofit.create(service);
    }
}
