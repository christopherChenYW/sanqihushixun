package org.cyw.httpclientandstroage.service;


import okhttp3.ResponseBody;
import retrofit2.Call;

import retrofit2.http.GET;
import retrofit2.http.Path;

public interface HttpService {

    @GET("wxarticle/list/{Chapter}/{curPage}/json")
    Call<ResponseBody> getArticles(@Path("Chapter") Integer Chapter, @Path("curPage") Integer curPage);

}
