package org.cyw.httpclientandstroage.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import org.cyw.httpclientandstroage.R;
import org.cyw.httpclientandstroage.pojo.Article;

import java.util.Date;
import java.util.List;

public class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.ViewHolder> {

    private List<Article> appInfoList;


    static class ViewHolder extends RecyclerView.ViewHolder{
        TextView article_title;
        TextView article_author;


        public ViewHolder (View view)
        {
            super(view);
            article_title = (TextView) view.findViewById(R.id.article_title);
            article_author = (TextView) view.findViewById(R.id.article_author);

        }

    }

    public ArticleAdapter(List <Article> fruitList){
        appInfoList = fruitList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        Article fruit = appInfoList.get(position);
        holder.article_title.setText(fruit.getTitle());
        holder.article_author.setText(fruit.getAuthor());
    }

    @Override
    public int getItemCount(){
        return appInfoList.size();
    }}