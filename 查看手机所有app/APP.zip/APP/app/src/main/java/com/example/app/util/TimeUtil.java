package com.example.app.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeUtil {
    private static String DATE_FORMAT="yyyy-MM-dd HH:mm:ss";
    public static String dateFormat(Date date){
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.format(date);
    }
}
