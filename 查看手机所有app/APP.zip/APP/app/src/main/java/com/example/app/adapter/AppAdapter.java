package com.example.app.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.example.app.R;
import com.example.app.pojo.AppInfo;
import com.example.app.util.AppUtils;
import com.example.app.util.TimeUtil;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.ViewHolder> {

    private List<AppInfo> appInfoList;


    static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView iv_app;
        TextView app_title;
        TextView app_version;
        TextView date;
        Button button;
        View view;

        public ViewHolder (View view)
        {
            super(view);
            view=view;
            iv_app = (ImageView) view.findViewById(R.id.iv_app);
            app_title = (TextView) view.findViewById(R.id.app_title);
            app_version=(TextView)view.findViewById(R.id.app_version);
            date=(TextView)view.findViewById(R.id.date);
            button=(Button)view.findViewById(R.id.open);
        }

    }

    public AppAdapter(List <AppInfo> fruitList){
        appInfoList = fruitList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        ViewHolder holder = new ViewHolder(view);
       holder.button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AppUtils.openApp(view.getContext(), appInfoList.get(holder.getAdapterPosition()).getPackageName());
           }
       });
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        AppInfo fruit = appInfoList.get(position);
        holder.iv_app.setImageDrawable(fruit.getImage());
        holder.app_title.setText(fruit.getAppName());
        holder.app_version.setText("版本："+fruit.getVersionName());
        holder.date.setText("安装时间："+ TimeUtil.dateFormat(new Date(fruit.getFirstInstallTime())));
    }

    @Override
    public int getItemCount(){
        return appInfoList.size();
    }}