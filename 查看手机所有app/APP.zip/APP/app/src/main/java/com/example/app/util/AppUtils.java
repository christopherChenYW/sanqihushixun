package com.example.app.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.util.Log;

import com.example.app.pojo.AppInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * created on 2020/8/3 20:24
 *
 * @author Scarf Gong
 */
public class AppUtils {
    private static final String TAG = "AppUtils";

    public static List<AppInfo> scanLocalInstallAppList(PackageManager packageManager) {
        List myAppInfos = new ArrayList();
        try {
            List packageInfos = packageManager.getInstalledPackages(0);

            // 建立一个类别为CATEGORY_LAUNCHER的该包名的Intent
            Intent resolveIntent = new Intent(Intent.ACTION_MAIN, null);
            resolveIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            // 经过getPackageManager()的queryIntentActivities方法遍历,获得全部能打开的app的packageName
            List<ResolveInfo> resolveinfoList =packageManager
                    .queryIntentActivities(resolveIntent, 0);
            Set<String> allowPackages = new HashSet();
            for (ResolveInfo resolveInfo : resolveinfoList) {
                allowPackages.add(resolveInfo.activityInfo.packageName);
            }

            for (int i = 0; i < packageInfos.size(); i++) {
                PackageInfo packageInfo = (PackageInfo) packageInfos.get(i);
                if(!allowPackages.contains(packageInfo.packageName)) continue;
                //过滤掉系统app
//                if ((ApplicationInfo.FLAG_SYSTEM & packageInfo.applicationInfo.flags) != 0) {
//                    continue;
//                }
                AppInfo myAppInfo = new AppInfo();
                String appName = packageInfo.applicationInfo.loadLabel(packageManager).toString();
                myAppInfo.setVersionName(packageInfo.versionName);
                myAppInfo.setFirstInstallTime(packageInfo.firstInstallTime);
                myAppInfo.setAppName(appName);
                myAppInfo.setPackageName(packageInfo.packageName);
                if (packageInfo.applicationInfo.loadIcon(packageManager) == null) {
                    continue;
                }
                myAppInfo.setImage(packageInfo.applicationInfo.loadIcon(packageManager));
                myAppInfos.add(myAppInfo);
            }
        } catch (Exception e) {
            Log.e(TAG, "获取应用包信息失败");
        }
        return myAppInfos;
    }

    public static void openApp(Context context, String packageName) {
        final Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        context.startActivity(intent);}

}

