package org.cyw.homework4.viewModel;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import org.cyw.homework4.callback.LoginCallBack;
import org.cyw.homework4.callback.LoginShowCallBack;
import org.cyw.homework4.dao.UserDao;
import org.cyw.homework4.database.MyDataBase;
import org.cyw.homework4.pojo.User;
import org.cyw.homework4.service.LoginService;
import org.cyw.homework4.service.LoginShowService;
import org.cyw.homework4.service.serviceImpl.LoginServiceImpl;
import org.cyw.homework4.service.serviceImpl.LoginShowServiceImpl;

import java.util.ArrayList;
import java.util.List;

public class LoginShowViewAndModel extends ViewModel {
    private static final String TAG = "LoginShowViewModel";
    private LoginShowService loginModel;

    public MutableLiveData<List<User>> userList = new MutableLiveData<List<User>>();
    public MutableLiveData<Boolean> progressViewState = new MutableLiveData<Boolean>();


    public LoginShowViewAndModel() {
        initData();
    }


    private void initData() {
        userList.setValue(new ArrayList<>());
        loginModel = new LoginShowServiceImpl();
        progressViewState.setValue(false);
    }

    public LiveData<List<User>> getUser() {
        return userList;
    }

    public MutableLiveData<Boolean> getProgressViewState() {
        return progressViewState;
    }

    /**
     * 开始登录
     */
    public void getData(View view) {
        progressViewState.setValue(true);

        loginModel.showData(
                new LoginShowCallBack() {
                    @Override
                    public void onSuccess(List<User> list) {
                        progressViewState.postValue(false);
                        userList.postValue(list);
                        Looper.prepare();
                        Toast.makeText(view.getContext(), "获取数据成功", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onFail(int errCode) {
                        //模拟，收到登录成功，修改账号显示的值
                        progressViewState.postValue(false);
                        Toast.makeText(view.getContext(), "获取数据发生错误", Toast.LENGTH_LONG).show();
                    }
                }, view.getContext());
    }


}
