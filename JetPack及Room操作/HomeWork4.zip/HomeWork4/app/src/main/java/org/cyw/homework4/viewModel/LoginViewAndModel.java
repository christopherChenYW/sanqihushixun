package org.cyw.homework4.viewModel;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import org.cyw.homework4.SecondActivity;
import org.cyw.homework4.callback.LoginCallBack;
import org.cyw.homework4.dao.UserDao;
import org.cyw.homework4.database.MyDataBase;
import org.cyw.homework4.pojo.User;
import org.cyw.homework4.service.LoginService;
import org.cyw.homework4.service.serviceImpl.LoginServiceImpl;

public class LoginViewAndModel extends ViewModel {
    private static final String TAG = "LoginViewModel";
    private LoginService loginModel;

    public MutableLiveData<User> user = new MutableLiveData<User>();
    public MutableLiveData<Boolean> progressViewState = new MutableLiveData<Boolean>();

    //创建登录状态监听器
    private MutableLiveData<Boolean> loginState;

    public MutableLiveData<Boolean> getLoginState() {
        if (loginState == null) {
            loginState = new MutableLiveData<Boolean>();
        }
        return loginState;
    }


    public LoginViewAndModel() {
        initData();
    }


    private void initData() {
        User userBean = new User("", "");
        user.setValue(userBean);
        loginModel = new LoginServiceImpl();
        progressViewState.setValue(false);
    }

    public LiveData<User> getUser() {
        return user;
    }

    public MutableLiveData<Boolean> getProgressViewState() {
        return progressViewState;
    }

    public void goToLogin(View view) {

        login(view);
    }

    /**
     * 开始登录
     */
    public void login(View view) {

        if (getUser().getValue().getUserName() == null || getUser().getValue().getUserName() == "") {
            return;
        }
        if (getUser().getValue().getPassword() == null || getUser().getValue().getPassword() == "") {
            return;
        }
        progressViewState.setValue(true);

        //获取LiveData的value
        String account = getUser().getValue().getUserName();
        String password = getUser().getValue().getPassword();

        loginModel.login(account, password,
                new LoginCallBack() {
                    @Override
                    public void onSuccess(String msg) {
                        //setValue 立马更新LiveData的值，需注意在主线程才可调用
                        progressViewState.setValue(false);
                        //postValue 异步更新LiveData的值，可在子线程调用
                        loginState.postValue(true);
                        saveUser(view);
                        goSecond(view.getContext(), SecondActivity.class);

                    }

                    @Override
                    public void onFail(int errCode) {
                        //模拟，收到登录成功，修改账号显示的值
                        progressViewState.setValue(false);
                        loginState.postValue(false);
                    }

                });
    }

    private void saveUser(View view) {
        AsyncTask.execute(() -> {
                //Write your db code here);
            User userInfo = user.getValue();
            UserDao userDao = MyDataBase.getAppDataBase(view.getContext()).getUserDao();
            int count = userDao.getCountByName(userInfo.getUserName());
            if (count < 1) userDao.insert(userInfo);
        }
        );
    }

    private void goSecond(Context context, Class second) {
        Intent intent = new Intent(context, second);
        context.startActivity(intent);
    }
}
