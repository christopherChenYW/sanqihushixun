package org.cyw.homework4;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.cyw.homework4.databinding.ActivityMainBinding;
import org.cyw.homework4.viewModel.LoginViewAndModel;

public class MainActivity extends AppCompatActivity {


    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //获取viewModel示例
        LoginViewAndModel viewModel = new ViewModelProvider(this,
                new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(LoginViewAndModel.class);

        //将View层和ViewModel层关联起来
        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        binding.setLoginView(viewModel);

        //设置dataBinding的生命周期，设置后LiveData才会生效
        binding.setLifecycleOwner(this);

        //监听登录状态
        viewModel.getLoginState().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable final Boolean loginState) {

                assert loginState != null;
                if (loginState) {
                    Toast.makeText(getBaseContext(), "登录成功", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getBaseContext(), "登录失败", Toast.LENGTH_LONG).show();
                }
            }
        });

        viewModel.getProgressViewState().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean isShowProgress) {
                if (isShowProgress) {
                    showProgressDialog();
                } else {
                    hideProgressDialog();
                }

            }
        });
    }

    /**
     * 显示加载框
     */
    public void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(this);
        }
        progressDialog.setMessage("帐密登录中 ...");
        progressDialog.show();
    }

    /**
     * 隐藏加载框
     */
    public void hideProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}