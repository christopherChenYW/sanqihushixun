package org.cyw.homework4.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import org.cyw.homework4.R;
import org.cyw.homework4.pojo.User;


import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private List<User> appInfoList;


    static class ViewHolder extends RecyclerView.ViewHolder{
        TextView article_title;


        public ViewHolder (View view)
        {
            super(view);
            article_title = (TextView) view.findViewById(R.id.user_account);

        }

    }
    public void setData(List<User> list){this.appInfoList=list;}

    public UserAdapter(List <User> fruitList){
        appInfoList = fruitList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        User fruit = appInfoList.get(position);
        holder.article_title.setText("用户账号："+fruit.getUserName());
    }

    @Override
    public int getItemCount(){
        return appInfoList.size();
    }}