package org.cyw.homework4.service.serviceImpl;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.cyw.homework4.callback.LoginShowCallBack;
import org.cyw.homework4.dao.UserDao;
import org.cyw.homework4.database.MyDataBase;
import org.cyw.homework4.pojo.User;
import org.cyw.homework4.service.LoginShowService;

import java.util.List;

public class LoginShowServiceImpl  implements LoginShowService {
    private static final long DELAY_INTERVAL = 1000;

    @Override
    public void showData(LoginShowCallBack loginCallBack, Context context) {
        //TODO 省略校验代码
        if (loginCallBack == null) {
            return;
        }
        //仅作为模拟所以放在主线程中，若正式网络请求数据，需在子线程发起网络请求，避免阻塞主线程
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                AsyncTask.execute(()->{
                    UserDao userDao = MyDataBase.getAppDataBase(context).getUserDao();
                    List<User> list = userDao.getAll();
                    loginCallBack.onSuccess(list);
                });
            }
        }, DELAY_INTERVAL);

    }
}
