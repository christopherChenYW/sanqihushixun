package org.cyw.homework4.service;

import org.cyw.homework4.callback.LoginCallBack;

public interface LoginService {

    long DELAY_INTERVAL = 3000L; //模拟登录等待时间 3s

    void login(String userName,
               String password,
               LoginCallBack loginCallBack);
}
