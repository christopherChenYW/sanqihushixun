package org.cyw.homework4.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import org.cyw.homework4.pojo.User;

import java.util.List;

@Dao
public interface UserDao {
    //在这里可以将sql语句设置成一个方法，让其他地方可以调用，比如：
    @Query("select user_name,password from user_account")
    List<User> getAll();

    //在这里可以将sql语句设置成一个方法，让其他地方可以调用，比如：
    @Query("select count(*) from user_account where user_name= :name")
    int getCountByName(String name);

    @Insert
    void insert(User user);
}
