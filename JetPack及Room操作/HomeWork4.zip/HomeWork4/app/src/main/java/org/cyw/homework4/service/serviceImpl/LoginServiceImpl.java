package org.cyw.homework4.service.serviceImpl;

import android.os.Handler;
import android.os.Looper;

import org.cyw.homework4.callback.LoginCallBack;
import org.cyw.homework4.service.LoginService;

public class LoginServiceImpl implements LoginService {

    @Override
    public void login(String userName, String password, LoginCallBack loginCallBack) {
        //TODO 省略校验代码
        if (loginCallBack == null) {
            return;
        }

        //仅作为模拟所以放在主线程中，若正式网络请求数据，需在子线程发起网络请求，避免阻塞主线程
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                //控制器更新UI
                loginCallBack.onSuccess(userName);
            }
        }, DELAY_INTERVAL);
    }
}
