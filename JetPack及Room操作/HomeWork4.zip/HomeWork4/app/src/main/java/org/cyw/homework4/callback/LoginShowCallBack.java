package org.cyw.homework4.callback;

import org.cyw.homework4.pojo.User;

import java.util.List;

public interface LoginShowCallBack {
    void onSuccess(List<User> list);
    void onFail(int errCode);
}
