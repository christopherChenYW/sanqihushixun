package org.cyw.homework4.callback;

public interface LoginCallBack {
    void onSuccess(String msg);
    void onFail(int errCode);
}
