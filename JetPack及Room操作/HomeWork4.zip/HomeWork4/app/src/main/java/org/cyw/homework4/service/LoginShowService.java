package org.cyw.homework4.service;

import android.content.Context;

import org.cyw.homework4.callback.LoginShowCallBack;

public interface LoginShowService {
    void showData(LoginShowCallBack loginShowCallBac, Context contextk);
}
