package org.cyw.homework4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import org.cyw.homework4.adapter.UserAdapter;

import org.cyw.homework4.databinding.ActivitySecondBinding;
import org.cyw.homework4.pojo.User;
import org.cyw.homework4.view.SpaceItemDecoration;
import org.cyw.homework4.viewModel.LoginShowViewAndModel;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        //获取viewModel示例
        LoginShowViewAndModel viewModel = new ViewModelProvider(this,
                new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(LoginShowViewAndModel.class);

        //将View层和ViewModel层关联起来
        ActivitySecondBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_second);
        binding.setLoginAndShowModel(viewModel);

        //设置dataBinding的生命周期，设置后LiveData才会生效
        binding.setLifecycleOwner(this);

        viewModel.getProgressViewState().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean isShowProgress) {
                if (isShowProgress) {
                    showProgressDialog();
                } else {
                    hideProgressDialog();
                }
            }
        });
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        UserAdapter adapter = new UserAdapter(new ArrayList<>());
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(getBaseContext(), DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.addItemDecoration(new SpaceItemDecoration(0, 30));
        recyclerView.setAdapter(adapter);
        viewModel.getUser().observe(this, new Observer<List<User>>() {
            @Override
            public void onChanged(List<User> list) {
                    adapter.setData(list);
                    adapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * 显示加载框
     */
    public void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(this);
        }
        progressDialog.setMessage("获取数据中 ...");
        progressDialog.show();
    }

    /**
     * 隐藏加载框
     */
    public void hideProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}