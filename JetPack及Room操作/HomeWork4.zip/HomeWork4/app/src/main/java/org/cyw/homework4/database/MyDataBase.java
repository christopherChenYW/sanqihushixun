package org.cyw.homework4.database;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import org.cyw.homework4.dao.UserDao;
import org.cyw.homework4.pojo.User;

@Database(entities = {User.class},version=1,exportSchema = false)
public abstract class MyDataBase extends RoomDatabase {
    public abstract UserDao getUserDao();

    private static final String DB_NAME = "room_db";
    // 静态内部类
    private static class SingleToneHolder {
        private volatile static MyDataBase appDataBase = null;

        static MyDataBase getInstance(Context context) {
            if (appDataBase == null) {
                synchronized (MyDataBase.class) {
                    if (appDataBase == null) {
                        appDataBase = buildDatabase(context);
                    }
                }
            }
            return appDataBase;
        }

        private static MyDataBase buildDatabase(Context context) {
            return Room.databaseBuilder(context, MyDataBase.class, DB_NAME)
                    .addCallback(new RoomDatabase.Callback() {
                        @Override
                        public void onCreate(@NonNull SupportSQLiteDatabase db) {
                            super.onCreate(db);
                            // 第一次创建数据库会回调此方法，可以做初始化数据之类的操作
                            Log.e(DB_NAME, "room_db 数据库第一次创建成功！");

                        }

                        @Override
                        public void onOpen(@NonNull SupportSQLiteDatabase db) {
                            super.onOpen(db);
                            Log.e(DB_NAME, "room_db 数据库 onOpen！");
                        }
                    })
                    .build();
        }
    }
    // 向外提供方法
    public static MyDataBase getAppDataBase(Context context) {
        return SingleToneHolder.getInstance(context);
    }

}

